import IosScrollLock from './IosScrollLock';
export default IosScrollLock;
export { IosScrollLock };
export type { IosScrollLockProps } from './IosScrollLock';